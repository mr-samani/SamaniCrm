https://localhost:44342/.well-known/openid-configuration


